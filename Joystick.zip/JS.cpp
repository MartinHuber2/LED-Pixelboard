#include "Arduino.h"
#include "JS.h"

 JS::JS(int xpin, int ypin, int swpin){
    this->xpin = xpin;
    this->ypin = ypin;
    this->swpin = swpin;
    pinMode(xpin, INPUT);
    pinMode(ypin, INPUT);
    pinMode(swpin, INPUT_PULLUP);
  }

  boolean JS::getSW(){
    return !digitalRead(this->swpin);
  }
  int JS::getX(){
    return analogRead(this->xpin);
  }
  int JS::getY(){
    return analogRead(this->ypin);
  }

#ifndef JS_h
#define JS_h
#include "Arduino.h"

class JS{
  private:
  int xpin, ypin, swpin;
  

  public:

  JS(int xpin, int ypin, int swpin);

  boolean getSW();
  int getX();
  int getY();
};
#endif

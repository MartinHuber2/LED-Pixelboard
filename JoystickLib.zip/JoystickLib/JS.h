#ifndef JS_h
#define JS_h
#include "Arduino.h"

class JS{
  private:
  int xpin, ypin, swpin; 
  boolean aktuellerZustand, letzterZustand;
  
  public:
  JS(int xpin, int ypin, int swpin);

  boolean getSwitch();
  int getX();
  int getY();
  boolean getSteigendeFlanke();
  boolean getFallendeFlanke();
};
#endif

#include "Arduino.h"
#include "JS.h"

 JS::JS(int xpin, int ypin, int swpin){
    this->xpin = xpin;
    this->ypin = ypin;
    this->swpin = swpin;
    pinMode(xpin, INPUT);
    pinMode(ypin, INPUT);
    pinMode(swpin, INPUT_PULLUP);
  }

  boolean JS::getSwitch(){
    this->aktuellerZustand = !digitalRead(this->swpin);
    return this->aktuellerZustand;
  }
  int JS::getX(){
    return analogRead(this->xpin);
  }
  int JS::getY(){
    return analogRead(this->ypin);
  }
  boolean JS::getSteigendeFlanke(){
    getSwitch();
    boolean steig = aktuellerZustand && !letzterZustand;
    this->letzterZustand = this->aktuellerZustand;
    return steig;
    }
  boolean JS::getFallendeFlanke(){
    getSwitch();
    boolean fall = !aktuellerZustand && letzterZustand;
    this->letzterZustand = this->aktuellerZustand;
    return fall;
    }
